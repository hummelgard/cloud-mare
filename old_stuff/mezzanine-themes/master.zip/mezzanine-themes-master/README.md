# mezzanine-themes

### Free themes for Mezzanine CMS.

 [demo](http://thecodinghouse.in/themes/)

This is a mezzanine project which contains free mezzanine themes(flat/nova/solid/moderna).

Download and run the project to try each theme by changing theme name in settings.py